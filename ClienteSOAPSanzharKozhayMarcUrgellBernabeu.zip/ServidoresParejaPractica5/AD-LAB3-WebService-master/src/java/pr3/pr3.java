/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pr3;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import static java.lang.System.out;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;
import java.util.List;

/**
 *
 * @author marcu
 */
@WebService(serviceName = "pr3")
@Stateless()
public class pr3 {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "RegisterImage")
    public Boolean RegisterImage(@WebParam(name = "img") imagen img) {

        boolean res;
        File f;        
        DB db = new DB();        
        
        
        res = db.insertImage(img.getTitle(),img.getDescription(),img.getKeywords(), img.getAuthor(),img.getCreationDate());
        
        
        if (res){            
            
            Decoder decoder = Base64.getUrlDecoder();
            byte[] decodedBytes = Base64.getDecoder().decode(img.getEncodedData());
            String path = "C:\\Users\\tuxis\\Documents\\ad\\AD\\ServidoresParejaPractica5\\AD-LAB3-WebService-master\\web\\images\\"+img.getFilename() + ".jpg";
            System.out.println(decodedBytes.toString());
            try (OutputStream outStream = new FileOutputStream(path)) {
                
                outStream.write(decodedBytes);
                outStream.close();
             
            } catch (IOException ex) {
                Logger.getLogger(pr3.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }
        return res;
    }
    
    /**
     * Web service operation
    */
    @WebMethod(operationName = "ListImages")
    public List<imagen> ListImages() {
        List<imagen> res;
        File f;
        byte[] fileContent;
        
        DB db = new DB();                       
        res =  db.getAllImagenes();
        
        try{
            for(imagen img : res){
                f = new File("C:\\Users\\tuxis\\Documents\\ad\\AD\\ServidoresParejaPractica5\\AD-LAB3-WebService-master\\web\\images\\"+img.getFilename());
                fileContent= Files.readAllBytes(f.toPath());
                String encoded = Base64.getEncoder().encodeToString(fileContent);
                img.setEncodedData(encoded);
                img.setStringId(Integer.toString(img.getId()));
            }
            return res;
        }catch (IOException e) {
            throw new IllegalStateException("could not read file ", e);            
        } 
    }
    
    
    private boolean setUpImageEncodedData(imagen img){
        
        File f;
        byte[] fileContent;
        if(img != null){
            try{
                f = new File("C:\\Users\\tuxis\\Documents\\ad\\AD\\ServidoresParejaPractica5\\AD-LAB3-WebService-master\\web\\images\\"+img.getFilename());
                
                fileContent= Files.readAllBytes(f.toPath());
                
                String encoded = Base64.getEncoder().encodeToString(fileContent);
                img.setEncodedData(encoded);
                img.setStringId(Integer.toString(img.getId()));
                return true;
            }catch (IOException e) {
                throw new IllegalStateException("could not read file ", e);            
            } 
        }
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "SearchbyId")
    public imagen SearchbyId(@WebParam(name = "id") int id) {
        
        DB db = new DB();  
        imagen img = db.getImageID(id);
        
        //if(setUpImageEncodedData(img)) 
            return img;

        //return null;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "SearchbyTitle")
    public List<imagen> SearchbyTitle(@WebParam(name = "titulo") String titulo) {
        File f;
        byte[] fileContent;
        DB db = new DB();  
        List<imagen> img = db.getImage(titulo);
        
        for(imagen i : img){
            setUpImageEncodedData(i);
        }
        return img; 
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "SearchbyCreaDate")
    public List<imagen> SearchbyCreaDate(@WebParam(name = "date") String date) {
        File f;
        byte[] fileContent;
        DB db = new DB();  
        List<imagen> img = db.getImageCD(date);
        
        for(imagen i : img){
            setUpImageEncodedData(i);
        }
        return img; 
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "SearchbyAuthor")
    public List<imagen> SearchbyAuthor(@WebParam(name = "autor") String autor) {
        File f;
        byte[] fileContent;
        DB db = new DB();  
        List<imagen> img = db.getImageAutor(autor);
        
        for(imagen i : img){
            setUpImageEncodedData(i);
        }
        return img; 
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "SearchbyKeywords")
    public List<imagen> SearchbyKeywords(@WebParam(name = "keywords") String keywords) {
        File f;
        byte[] fileContent;
        DB db = new DB();  
        List<imagen> img = db.getImagePC(keywords);
        
        for(imagen i : img){
            setUpImageEncodedData(i);
        }
        return img; 
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "ModifyImage")
    public int ModifyImage(@WebParam(name = "imagen") imagen imagen) {
        System.out.println("modify connected");
        DB db = new DB();
        imagen.convertId();
        int res = db.modificarImagenImg(imagen);
        return res;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "DeleteImage")
    public int DeleteImage(@WebParam(name = "iamgen") imagen imagen) {
        DB db = new DB();
        imagen.convertId();
        int res = db.deleteImageIDWithRes(imagen.getId());
        return res;
    }


    @WebMethod(operationName = "getNewImageId")
    public int getNewImageId() {
        DB db = new DB();
        return db.newImageID();
    }

   @WebMethod(operationName = "userExists")
   public boolean userExists(String login, String password){
       DB db = new DB();
       return db.usuarioExists(login, password);
   }
}
