/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pr3;

import java.io.File;
import static java.lang.Integer.parseInt;

/**
 *
 * @author marcu
 */
public class imagen {
    private int id;
    private String title;
    private String description;
    private String keywords;
    private String author;
    private String creationDate;
    private String storageDate;
    private String filename;
    private String encodedData;
    private String StringId;
    //final private String path = "C:\\Users\\marcu\\Documents\\NetBeansProjects\\Practica3\\web\\Images\\";
    //public static String imageFolderPath = System.getProperty("user.home") + "/NetBeansProjects/AD-LAB2/web/images/" ;
            
    public imagen(){
        
    }
    
    public imagen(
    int id,
    String title,
    String description,
    String keywords,
    String author,
    String creationDate,
    String storageDate,
    String filename,
    String encodedData
    ){
        this.id = id;
        this.title = title;
        this.description = description;
        this.keywords = keywords;
        this.author = author;
        this.creationDate = creationDate;
        this.storageDate = storageDate;
        this.filename = filename;
        this.encodedData = encodedData;
    }

    public String getEncodedData() {
        return encodedData;
    }

    public void setEncodedData(String encodedData) {
        this.encodedData = encodedData;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int newId){
        this.id = newId;
    }
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getStorageDate() {
        return storageDate;
    }

    public void setStorageDate(String storageDate) {
        this.storageDate = storageDate;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }
        
    public String getStringId() {
        return StringId;
    }

    public void setStringId(String StringId) {
        this.StringId = StringId;
    }
    
    public void convertId(){
        this.id = parseInt(this.StringId);
    }
}
